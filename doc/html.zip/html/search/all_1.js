var searchData=
[
  ['conclusion_0',['Conclusion',['../md__r_e_a_d_m_e.html',1,'']]]
];

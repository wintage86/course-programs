var searchData=
[
  ['printint_0',['printInt',['../group__auxilary.html#gaa5ea5c969c7f17f7f51bbef828e4c284',1,'stack.c']]]
];

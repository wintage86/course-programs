var searchData=
[
  ['stack_0',['Stack',['../struct_stack.html',1,'']]]
];
